from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)

USER_DB = 'users.json'

def load_users():
    if not os.path.exists(USER_DB):
        return []
    with open(USER_DB, 'r') as file:
        return json.load(file)

def save_users(users):
    with open(USER_DB, 'w') as file:
        json.dump(users, file, indent=2)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({'success': False, 'message': 'Username & password required'}), 400

    users = load_users()
    if any(u['username'] == username for u in users):
        return jsonify({'success': False, 'message': 'Username already exists'}), 409

    users.append({'username': username, 'password': password, 'role': 'user'})
    save_users(users)
    return jsonify({'success': True, 'message': 'User registered successfully'})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    users = load_users()
    user = next((u for u in users if u['username'] == username and u['password'] == password), None)

    if user:
        return jsonify({'success': True, 'role': user['role']})
    else:
        return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

if __name__ == '__main__':
    app.run(debug=True)
